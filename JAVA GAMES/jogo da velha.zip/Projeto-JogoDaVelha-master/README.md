# Projeto-Jogo-da-Velha

Desenvolvendo um Jogo da Velha na internet, seguindo Porjeto (Instrutor: Victor Ruschoni): "Criando seu próprio jogo da velha com HTML e Javascript" existente na plataforma de cursos online Digital Innovation One, no link de Labs-PRO.

## Técnologias utilizadas:

- HTML5;
- CSS;
- JavaScript.
